## APIs

### Project
To build a timeline using [Dipity](http://www.dipity.com) with photos from Flickr and/or 500px. For example, one could make a photo timeline grabbing photos tagged with "Olympics 2012" or "Arab Spring."

Follow the complete tutorial [here](http://newcoder.io/api)
