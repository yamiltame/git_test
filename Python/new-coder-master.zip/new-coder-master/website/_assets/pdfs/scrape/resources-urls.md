### Introduction

1. http://scrapy.org
2. http://www.livingsocial.com
3. http://newcoder.io/dataviz/
4. http://twistedmatrix.com/trac/
5. http://lxml.de/
6. http://newcoder.io/networks/
7. http://doc.scrapy.org/en/0.16/intro/tutorial.html
8. http://www.sqlalchemy.org/
9. http://twitter.com/craigkerstiens
10. http://www.craigkerstiens.com/2012/04/30/why-postgres/
11. http://en.wikipedia.org/wiki/Cron#Predefined_scheduling_definitions
12. http://support.microsoft.com/kb/308569
13. http://technet.microsoft.com/en-us/library/bb726974.aspx
14. http://technet.microsoft.com/en-us/library/cc725744.aspx
15. http://newcoder.io/scrape/part-0/

### Part 0

1. http://newcoder.io/begin/setup-your-machine
2. http://pypi.python.org/pypi/virtualenvwrapper
3. http://virtualenvwrapper.readthedocs.org/en/latest/
4. http://newcoder.io/scrape/part-1/

### Part 1

1. https://docs.djangoproject.com/en/1.5/intro/tutorial01/
2. http://newcoder.io/scrape/part-2/

### Part 2

1. http://doc.scrapy.org/en/0.16/topics/selectors.html#topics-selectors
2. http://doc.scrapy.org/en/0.16/topics/selectors.html#topics-selectors
3. http://www.livingsocial.com/cities/1719-newyork-citywide
4. http://doc.scrapy.org/en/0.16/topics/selectors.html#working-with-relative-xpaths
5. https://developers.google.com/chrome-developer-tools/
6. https://addons.mozilla.org/en-us/firefox/addon/firepath/
7. http://doc.scrapy.org/en/0.16/intro/tutorial.html#what-just-happened-under-the-hood
8. http://doc.scrapy.org/en/0.16/topics/loaders.html#scrapy.contrib.loader.processor.Join
9. http://stackoverflow.com/questions/231767/the-python-yield-keyword-explained
10. http://newcoder.io/scrape/part-3/


### Part 3

1. http://www.postgresql.org/docs/9.2/static/index.html
2. http://doc.scrapy.org/en/0.16/intro/tutorial.html#creating-a-project
3. http://newcoder.io/scrape/part-4/


### Part 4



