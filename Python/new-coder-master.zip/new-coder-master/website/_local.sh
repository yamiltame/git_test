mynt gen -f _site && mynt serve _site -p 5000
