## Data Visualization

### Project
To parse data from a CSV or Excel file and plot it with matplotlib. Examples include: parsing local crime data and visualizing how often crime happens on Mondays versus Thursdays, etc.

Follow the complete tutorial [here](http://newcoder.io/dataviz)
